package com.perfboost.app

import java.util.concurrent.TimeUnit

/** Menjalankan perintah sebagai root (su). Kalau perangkat tidak di-root, hasilnya null. */
object Shell {
    @Volatile private var rootChecked = false
    @Volatile private var rootOk = false

    fun hasRoot(): Boolean {
        if (!rootChecked) {
            rootOk = run("id")?.contains("uid=0") == true
            rootChecked = true
        }
        return rootOk
    }

    fun recheckRoot() { rootChecked = false }

    fun su(cmd: String): String? = if (hasRootCached()) run(cmd) else null

    private fun hasRootCached() = hasRoot()

    private fun run(cmd: String): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(4, TimeUnit.SECONDS)) p.destroy()
        out
    } catch (e: Exception) {
        null
    }
}
