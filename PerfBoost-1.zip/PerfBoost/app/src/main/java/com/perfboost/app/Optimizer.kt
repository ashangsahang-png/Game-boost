package com.perfboost.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

data class OptimizeResult(val killed: Int, val freedMb: Long)

object Optimizer {

    /**
     * Menghentikan proses aplikasi pihak ketiga yang berjalan di latar belakang.
     * Tanpa root: killBackgroundProcesses (hanya proses yang sedang di background/cached).
     * Dengan root: am force-stop (lebih kuat).
     * Aplikasi ini sendiri, launcher, keyboard, dan aplikasi yang sedang di depan dilewati.
     */
    fun optimize(ctx: Context, foregroundPkg: String?): OptimizeResult {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = ctx.packageManager

        val before = availMb(am)

        val home = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName

        val skip = setOfNotNull(ctx.packageName, foregroundPkg, home)
        val root = Shell.hasRoot()

        var killed = 0
        for (app in pm.getInstalledApplications(0)) {
            val isSystem = app.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            if (isSystem || app.packageName in skip) continue
            if (app.flags and ApplicationInfo.FLAG_STOPPED != 0) continue // sudah berhenti
            if (root) Shell.su("am force-stop ${app.packageName}") else am.killBackgroundProcesses(app.packageName)
            killed++
        }

        Thread.sleep(600) // beri waktu sistem melepas memori
        val freed = (availMb(am) - before).coerceAtLeast(0)
        return OptimizeResult(killed, freed)
    }

    private fun availMb(am: ActivityManager): Long =
        ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem / (1024 * 1024)
}
