package com.perfboost.app

import android.app.ActivityManager
import android.content.Context
import java.io.File

data class Snapshot(
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val gpuPercent: Int?,   // null = tidak bisa dibaca di perangkat ini
    val fps: Int?,          // null = butuh root
    val foregroundPkg: String?
) {
    val ramPercent get() = if (ramTotalMb == 0L) 0 else (ramUsedMb * 100 / ramTotalMb).toInt()
}

class MetricsReader(private val ctx: Context) {

    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private var lastLayer: String? = null
    private var lastPkg: String? = null

    fun read(): Snapshot {
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = mi.totalMem / MB
        val used = total - mi.availMem / MB
        val pkg = foregroundPackage()
        return Snapshot(used, total, readGpu(), readFps(pkg), pkg)
    }

    // ---------- GPU ----------
    private val gpuFiles = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",           // Qualcomm Adreno
        "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
        "/sys/kernel/gpu/gpu_busy",                                // beberapa Qualcomm
        "/sys/class/misc/mali0/device/utilisation",                // Mali
        "/sys/devices/platform/13000000.mali/utilization",         // Mali (MediaTek/Exynos)
        "/sys/module/ged/parameters/gpu_loading"                   // MediaTek
    )

    private fun readGpu(): Int? {
        for (path in gpuFiles) {
            val raw = readFile(path) ?: continue
            val n = Regex("\\d+").find(raw)?.value?.toIntOrNull() ?: continue
            return n.coerceIn(0, 100)
        }
        return null
    }

    private fun readFile(path: String): String? {
        try {
            val f = File(path)
            if (f.canRead()) return f.readText().trim()
        } catch (_: Exception) {}
        return Shell.su("cat $path")?.trim()?.takeIf { it.isNotEmpty() && !it.contains("No such file") }
    }

    // ---------- Aplikasi di depan ----------
    private fun foregroundPackage(): String? {
        val out = Shell.su("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'") ?: return null
        val m = Regex("([a-zA-Z0-9_.]+)/[a-zA-Z0-9_.$]+").find(out) ?: return null
        return m.groupValues[1].takeIf { it != ctx.packageName }
    }

    // ---------- FPS (root) lewat SurfaceFlinger ----------
    private fun readFps(pkg: String?): Int? {
        if (pkg == null) return null
        if (pkg != lastPkg) { lastPkg = pkg; lastLayer = findLayer(pkg) }
        val layer = lastLayer ?: return null
        val out = Shell.su("dumpsys SurfaceFlinger --latency '$layer'") ?: return null
        val lines = out.lines().drop(1)
        // kolom ke-2 = waktu present (ns); 0 / Long.MAX = tidak valid
        val times = lines.mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it > 0 && it != Long.MAX_VALUE }
        if (times.size < 2) return null
        val last = times.max()
        val frames = times.count { last - it <= 1_000_000_000L }
        return frames.coerceAtMost(240)
    }

    private fun findLayer(pkg: String): String? {
        val layers = Shell.su("dumpsys SurfaceFlinger --list")?.lines()?.map { it.trim() } ?: return null
        return layers.firstOrNull { it.contains(pkg) && it.contains("SurfaceView") && !it.contains("Background") }
            ?: layers.firstOrNull { it.contains(pkg) && !it.startsWith("Background") }
    }

    companion object { private const val MB = 1024L * 1024L }
}
