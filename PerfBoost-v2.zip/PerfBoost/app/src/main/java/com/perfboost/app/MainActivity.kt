package com.perfboost.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var fpsV: TextView
    private lateinit var gpuV: TextView
    private lateinit var ramV: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private var fgPkg: String? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            fpsV.text = i.getStringExtra("fps") ?: "—"
            gpuV.text = i.getStringExtra("gpu") ?: "—"
            ramV.text = i.getStringExtra("ram") ?: "—"
            fgPkg = i.getStringExtra("pkg")?.takeIf { it.isNotEmpty() }
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(240, 98, 193)
        window.navigationBarColor = Color.rgb(252, 178, 227)

        val st = Stage(this)

        // Teks nilai di kanan label "FPS :", "GPU :", "RAM :" pada gambar.
        fpsV = st.value(430f, 1020f, 715f, 1084f, 34f)
        gpuV = st.value(430f, 1084f, 715f, 1146f, 34f)
        ramV = st.value(430f, 1146f, 715f, 1210f, 34f)

        // Tombol transparan tepat di atas tombol pada gambar.
        st.hotspot(297f, 413f, 700f, 518f, "Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        st.hotspot(228f, 542f, 700f, 612f, "Aktifkan Shizuku") { activateShizuku() }
        st.hotspot(232f, 650f, 700f, 720f, "Nyalakan overlay") { startOverlay() }
        st.hotspot(238f, 752f, 700f, 822f, "Matikan overlay") {
            OverlayService.stop(this)
            fpsV.text = "—"; gpuV.text = "—"; ramV.text = "—"
            toast("Overlay dimatikan")
        }
        st.hotspot(422f, 862f, 700f, 935f, "Optimize") { optimizeNow() }

        setContentView(st)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun activateShizuku() {
        worker.execute {
            Shell.recheck()
            val running = Shell.shizukuRunning()
            val ready = Shell.shizukuReady()
            runOnUiThread {
                when {
                    ready -> toast("Shizuku sudah aktif. FPS siap dibaca.")
                    !running -> toast("Shizuku belum berjalan. Buka aplikasi Shizuku lalu tekan Start.")
                    else -> { toast("Setujui izin Shizuku."); Shell.requestShizuku(100) }
                }
            }
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan tampil di atas aplikasi lain dulu (tombol paling atas).")
            return
        }
        OverlayService.start(this)
        toast("Overlay dinyalakan")
    }

    private fun optimizeNow() {
        toast("Mengoptimalkan…")
        worker.execute {
            val r = Optimizer.optimize(this, fgPkg)
            runOnUiThread { toast("${r.killed} aplikasi dihentikan, ± ${r.freedMb} MB RAM dibebaskan") }
        }
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(OverlayService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }
}
