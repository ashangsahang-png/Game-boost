package com.perfboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import java.util.concurrent.Executors

/** Overlay kecil yang tampil di atas aplikasi/game lain: FPS, GPU, RAM. Bisa digeser; ketuk = optimize. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var view: TextView
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var reader: MetricsReader
    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var running = false
    @Volatile private var holdUntil = 0L
    @Volatile private var last: Snapshot? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        reader = MetricsReader(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildOverlay()
        running = true
        loop()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay performa", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("PerfBoost aktif")
            .setContentText("Overlay FPS / GPU / RAM berjalan")
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildOverlay() {
        val d = resources.displayMetrics.density
        view = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = 0.06f
            textScaleX = 1.12f
            setSingleLine(true)
            setPadding((16 * d).toInt(), (6 * d).toInt(), (16 * d).toInt(), (6 * d).toInt())
            text = "FPS —    GPU —    RAM —"
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 119, 119, 119))
                cornerRadius = 200f
            }
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 120 }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    wm.updateViewLayout(view, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) quickOptimize()
            }
            true
        }
        wm.addView(view, params)
    }

    private fun quickOptimize() {
        holdUntil = System.currentTimeMillis() + 2500
        view.text = "Optimize…"
        worker.execute {
            val r = Optimizer.optimize(this, last?.foregroundPkg)
            holdUntil = System.currentTimeMillis() + 2500
            ui.post { view.text = "✔ ${r.killed} app  +${r.freedMb} MB" }
        }
    }

    private fun loop() {
        worker.execute {
            while (running) {
                val s = try { reader.read() } catch (_: Exception) { null }
                if (s != null) {
                    last = s
                    ui.post { if (running && System.currentTimeMillis() > holdUntil) view.text = format(s) }
                    sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).also { it.putExtra("fps", s.fps?.toString() ?: "—")
                        it.putExtra("gpu", s.gpuPercent?.let { g -> "$g%" } ?: "—")
                        it.putExtra("ram", "${s.ramPercent}%  (${"%.1f".format(s.ramUsedMb / 1024.0)} GB)")
                        it.putExtra("pkg", s.foregroundPkg ?: "") })
                }
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
            }
        }
    }

    private fun format(s: Snapshot): String {
        val fps = s.fps?.toString() ?: "—"
        val gpu = s.gpuPercent?.let { "$it%" } ?: "—"
        return "FPS $fps    GPU $gpu    RAM ${s.ramPercent}%"
    }

    override fun onDestroy() {
        running = false
        worker.shutdownNow()
        try { wm.removeView(view) } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "perfboost"
        const val ACTION_UPDATE = "com.perfboost.app.UPDATE"
        fun start(c: Context) = c.startForegroundService(Intent(c, OverlayService::class.java))
        fun stop(c: Context) = c.stopService(Intent(c, OverlayService::class.java))
    }
}
