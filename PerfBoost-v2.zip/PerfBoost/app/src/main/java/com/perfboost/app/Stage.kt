package com.perfboost.app

import android.content.Context
import android.graphics.Color
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

/**
 * Menampilkan gambar latar 720x1280 secara proporsional (rata atas), lalu menaruh tombol transparan
 * dan teks langsung di atas posisi tombol/label pada gambar. Koordinat dalam piksel gambar (720x1280).
 */
class Stage(ctx: Context) : ViewGroup(ctx) {

    private class Item(val v: View, val r: RectF, val textPx: Float)

    private val items = ArrayList<Item>()
    private val img = ImageView(ctx).apply {
        setImageResource(R.drawable.bg_home)
        scaleType = ImageView.ScaleType.FIT_XY
    }

    init {
        addView(img)
        // area kosong (layar lebih tinggi dari gambar) diisi warna yang menyambung dengan tepi bawah gambar
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(252, 178, 227), Color.WHITE)
        )
    }

    /** Tombol transparan dengan efek tekan. */
    fun hotspot(l: Float, t: Float, r: Float, b: Float, desc: String, onClick: () -> Unit) {
        val v = View(context).apply {
            isClickable = true
            contentDescription = desc
            background = StateListDrawable().apply {
                addState(
                    intArrayOf(android.R.attr.state_pressed),
                    GradientDrawable().apply { setColor(Color.argb(90, 255, 255, 255)); cornerRadius = 80f }
                )
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            }
            setOnClickListener { onClick() }
        }
        addView(v); items.add(Item(v, RectF(l, t, r, b), 0f))
    }

    /** Teks nilai (FPS/GPU/RAM) di sebelah label pada gambar. */
    fun value(l: Float, t: Float, r: Float, b: Float, textPx: Float): TextView {
        val v = TextView(context).apply {
            setTextColor(Color.rgb(74, 26, 122))
            setShadowLayer(6f, 0f, 1f, Color.argb(200, 255, 255, 255))
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            letterSpacing = 0.05f
            setSingleLine(true)
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            text = "—"
        }
        addView(v); items.add(Item(v, RectF(l, t, r, b), textPx))
        return v
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(
            resolveSize(MeasureSpec.getSize(wSpec), wSpec),
            resolveSize(MeasureSpec.getSize(hSpec), hSpec)
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = (r - l).toFloat(); val h = (b - t).toFloat()
        val s = minOf(w / 720f, h / 1280f)
        val ox = (w - 720f * s) / 2f
        fun place(v: View, rl: Float, rt: Float, rr: Float, rb: Float) {
            val x0 = (ox + rl * s).toInt(); val y0 = (rt * s).toInt()
            val x1 = (ox + rr * s).toInt(); val y1 = (rb * s).toInt()
            v.measure(
                MeasureSpec.makeMeasureSpec(x1 - x0, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(y1 - y0, MeasureSpec.EXACTLY)
            )
            v.layout(x0, y0, x1, y1)
        }
        place(img, 0f, 0f, 720f, 1280f)
        for (it in items) {
            val tv = it.v as? TextView
            if (tv != null && it.textPx > 0f) {
                val px = it.textPx * s
                if (tv.textSize != px) tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
            }
            place(it.v, it.r.left, it.r.top, it.r.right, it.r.bottom)
        }
    }
}
