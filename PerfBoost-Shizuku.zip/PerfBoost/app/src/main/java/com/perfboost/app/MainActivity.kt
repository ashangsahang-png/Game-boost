package com.perfboost.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var stats: TextView
    private lateinit var status: TextView
    private val worker = Executors.newSingleThreadExecutor()
    private var fgPkg: String? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val t = i.getStringExtra("txt") ?: return
            stats.text = t
            fgPkg = Regex("App\\s+: (.+)$").find(t)?.groupValues?.get(1)?.takeIf { it != "—" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F1115")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1115"))
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String, size: Float, color: String = "#FFFFFF", bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        }

        root.addView(label("PerfBoost", 28f, bold = true))
        root.addView(label("Monitor FPS • GPU • RAM + optimizer", 14f, "#8B93A1"))

        stats = label("Overlay belum aktif.\nNyalakan overlay untuk melihat data langsung.", 16f, "#7CFFB2").apply {
            typeface = Typeface.MONOSPACE
            setPadding(0, 48, 0, 48)
        }
        root.addView(stats)

        status = label("", 13f, "#FFB86B")
        root.addView(button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("Izinkan Shizuku (untuk FPS tanpa root)") {
            if (!Shell.shizukuRunning()) status.text = "Shizuku belum berjalan. Buka aplikasi Shizuku dan tekan Start dulu."
            else Shell.requestShizuku(100)
        })
        root.addView(button("Cek ulang akses") { Shell.recheck(); refreshCapabilities() })
        root.addView(button("2. Nyalakan overlay") { startOverlay() })
        root.addView(button("Matikan overlay") { OverlayService.stop(this); stats.text = "Overlay dimatikan." })
        root.addView(button("⚡ Optimize sekarang") { optimizeNow() })
        root.addView(status.apply { setPadding(0, 32, 0, 0) })

        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#0F1115")) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        refreshCapabilities()
    }

    private fun refreshCapabilities() {
        worker.execute {
            val mode = Shell.mode()
            val running = Shell.shizukuRunning()
            runOnUiThread {
                status.text = when (mode) {
                    Shell.Mode.SHIZUKU -> "Shizuku aktif: FPS aplikasi lain dan force-stop tersedia. (GPU tergantung perangkat.)"
                    Shell.Mode.ROOT -> "Root terdeteksi: FPS aplikasi lain, GPU, dan force-stop tersedia."
                    Shell.Mode.NONE ->
                        if (running) "Shizuku berjalan tapi belum diberi izin — tekan tombol Izinkan Shizuku."
                        else "Tanpa Shizuku/root: hanya RAM + optimize dasar. Untuk FPS, jalankan aplikasi Shizuku lalu tekan Izinkan Shizuku."
                }
            }
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Izin overlay belum diberikan — tekan tombol 1 dulu."
            return
        }
        OverlayService.start(this)
    }

    private fun optimizeNow() {
        status.text = "Mengoptimalkan…"
        worker.execute {
            val r = Optimizer.optimize(this, fgPkg)
            runOnUiThread { status.text = "Selesai: ${r.killed} aplikasi dihentikan, ± ${r.freedMb} MB RAM dibebaskan." }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCapabilities()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(OverlayService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }
}
