package com.perfboost.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

/**
 * Menjalankan perintah dengan hak lebih tinggi. Urutan: Shizuku -> root (su) -> tidak ada.
 * Shizuku menjalankan perintah sebagai "shell" (setara adb), cukup untuk dumpsys SurfaceFlinger (FPS) dan am force-stop.
 */
object Shell {
    enum class Mode { NONE, SHIZUKU, ROOT }

    @Volatile private var rootChecked = false
    @Volatile private var rootOk = false

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestShizuku(code: Int) {
        try { Shizuku.requestPermission(code) } catch (_: Throwable) {}
    }

    fun hasRoot(): Boolean {
        if (!rootChecked) {
            rootOk = runSu("id")?.contains("uid=0") == true
            rootChecked = true
        }
        return rootOk
    }

    fun recheck() { rootChecked = false }

    fun mode(): Mode = when {
        shizukuReady() -> Mode.SHIZUKU
        hasRoot() -> Mode.ROOT
        else -> Mode.NONE
    }

    /** true kalau bisa menjalankan perintah berhak tinggi (Shizuku atau root). */
    fun privileged(): Boolean = mode() != Mode.NONE

    fun exec(cmd: String): String? = when (mode()) {
        Mode.SHIZUKU -> runShizuku(cmd)
        Mode.ROOT -> runSu(cmd)
        Mode.NONE -> null
    }

    private fun runShizuku(cmd: String): String? = try {
        // newProcess bersifat private di Shizuku API 13, jadi dipanggil lewat refleksi.
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        collect(p)
    } catch (e: Throwable) {
        null
    }

    private fun runSu(cmd: String): String? = try {
        collect(ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start())
    } catch (e: Exception) {
        null
    }

    private fun collect(p: Process): String {
        val out = p.inputStream.bufferedReader().readText()
        if (!p.waitFor(4, TimeUnit.SECONDS)) p.destroy()
        return out
    }
}
