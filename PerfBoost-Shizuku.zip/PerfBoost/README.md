# PerfBoost

Overlay FPS / GPU / RAM di atas aplikasi lain + tombol optimize. Kotlin, tanpa dependensi UI tambahan.

## Build
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Run di HP (Android 8.0+), atau Build > Build APK(s).
3. Buka app → tombol 1 (izin overlay) → tombol 2 (nyalakan overlay).
4. Ketuk overlay = optimize cepat. Seret untuk memindahkan.

## Batasan Android
| Fitur | Tanpa root | Dengan root |
|---|---|---|
| RAM | ya | ya |
| GPU % | hanya jika file sysfs terbaca (jarang) | ya (Adreno/Mali/MediaTek) |
| FPS aplikasi/game lain | tidak bisa | ya (SurfaceFlinger) |
| Optimize | menghentikan proses background | force-stop semua app non-sistem |

## Akses FPS tanpa root (Shizuku)
Install Shizuku, start lewat Wireless Debugging, lalu di PerfBoost tekan "Izinkan Shizuku".
Urutan akses: Shizuku -> root -> terbatas.
