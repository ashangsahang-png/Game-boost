package com.perfboost.app

import android.app.ActivityManager
import android.content.Context
import java.io.File

data class Snapshot(
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val gpuPercent: Int?,   // null = tidak bisa dibaca di perangkat ini
    val fps: Int?,          // null = butuh root
    val foregroundPkg: String?
) {
    val ramPercent get() = if (ramTotalMb == 0L) 0 else (ramUsedMb * 100 / ramTotalMb).toInt()
}

class MetricsReader(private val ctx: Context) {

    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun read(): Snapshot {
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val total = mi.totalMem / MB
        val used = total - mi.availMem / MB
        val pkg = foregroundPackage()
        return Snapshot(used, total, readGpu(), readFps(pkg), pkg)
    }

    // ---------- GPU ----------
    private val gpuFiles = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",           // Qualcomm Adreno
        "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load",
        "/sys/kernel/gpu/gpu_busy",                                // beberapa Qualcomm
        "/sys/class/misc/mali0/device/utilisation",                // Mali
        "/sys/devices/platform/13000000.mali/utilization",         // Mali (MediaTek/Exynos)
        "/sys/module/ged/parameters/gpu_loading"                   // MediaTek
    )

    private fun readGpu(): Int? {
        for (path in gpuFiles) {
            val raw = readFile(path) ?: continue
            val n = Regex("\\d+").find(raw)?.value?.toIntOrNull() ?: continue
            return n.coerceIn(0, 100)
        }
        return null
    }

    private fun readFile(path: String): String? {
        try {
            val f = File(path)
            if (f.canRead()) return f.readText().trim()
        } catch (_: Exception) {}
        return Shell.exec("cat $path")?.trim()?.takeIf { it.isNotEmpty() && !it.contains("No such file") }
    }

    // ---------- Aplikasi di depan ----------
    private fun foregroundPackage(): String? {
        val out = Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'") ?: return null
        val m = Regex("([a-zA-Z0-9_.]+)/[a-zA-Z0-9_.$]+").find(out) ?: return null
        return m.groupValues[1].takeIf { it != ctx.packageName }
    }

    // ---------- FPS ----------
    private val layerCache = HashMap<String, Pair<Long, List<String>>>()

    private fun readFps(pkg: String?): Int? {
        if (pkg == null) return null
        for (layer in candidateLayers(pkg)) {
            fpsOfLayer(layer)?.let { return it }
        }
        return gfxinfoFps(pkg)
    }

    /** Daftar layer SurfaceFlinger milik aplikasi (SurfaceView/game dulu), di-cache 5 detik. */
    private fun candidateLayers(pkg: String): List<String> {
        val now = System.currentTimeMillis()
        layerCache[pkg]?.let { if (now - it.first < 5000 && it.second.isNotEmpty()) return it.second }
        val layers = Shell.exec("dumpsys SurfaceFlinger --list")?.lines()?.map { it.trim() } ?: return emptyList()
        val mine = layers.filter { it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds") }
        val sorted = mine.sortedBy { if (it.contains("SurfaceView")) 0 else if (it.contains("BLAST")) 1 else 2 }.take(6)
        layerCache[pkg] = now to sorted
        return sorted
    }

    private fun latencyTimes(layer: String): List<Long> {
        val out = Shell.exec("dumpsys SurfaceFlinger --latency '${layer.replace("'", "")}'") ?: return emptyList()
        return out.lines().drop(1).mapNotNull { line ->
            val cols = line.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            // kolom 2 = waktu present; kalau tidak valid pakai kolom 1 (desired present)
            cols.getOrNull(1)?.takeIf { it > 0 && it != Long.MAX_VALUE }
                ?: cols.getOrNull(0)?.takeIf { it > 0 && it != Long.MAX_VALUE }
        }
    }

    private fun fpsOfLayer(layer: String): Int? = countRecent(latencyTimes(layer))

    private fun countRecent(times: List<Long>): Int? {
        if (times.size < 2) return null
        val last = times.max()
        val age = System.nanoTime() - last
        if (age in 2_000_000_000L..60_000_000_000L) return 0   // layer diam (tidak ada frame baru)
        return times.count { last - it <= 1_000_000_000L }.coerceAtMost(240)
    }

    /** Cadangan untuk aplikasi biasa (HWUI). Game OpenGL/Vulkan tidak muncul di sini. */
    private fun gfxinfoTimes(pkg: String): List<Long> {
        val out = Shell.exec("dumpsys gfxinfo $pkg framestats") ?: return emptyList()
        val lines = out.lines()
        val h = lines.indexOfFirst { it.startsWith("Flags,") }
        if (h < 0) return emptyList()
        val col = lines[h].split(",").indexOf("IntendedVsync").takeIf { it >= 0 } ?: 1
        return lines.drop(h + 1).takeWhile { it.isNotBlank() && it[0].isDigit() }.mapNotNull {
            it.split(",").getOrNull(col)?.toLongOrNull()?.takeIf { v -> v > 0 && v != Long.MAX_VALUE }
        }
    }

    private fun gfxinfoFps(pkg: String): Int? = countRecent(gfxinfoTimes(pkg))

    /** Laporan untuk mencari tahu kenapa FPS tidak terbaca. */
    fun diagnose(pkg: String): String {
        val sb = StringBuilder()
        sb.appendLine("Android ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT}), ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
        sb.appendLine("Mode akses: ${Shell.mode()}")
        sb.appendLine("Aplikasi uji: $pkg")
        val list = Shell.exec("dumpsys SurfaceFlinger --list")
        if (list == null) { sb.appendLine("`--list` gagal dijalankan (null)"); return sb.toString() }
        val all = list.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val mine = all.filter { it.contains(pkg) }
        sb.appendLine("Layer total: ${all.size}, milik app: ${mine.size}")
        mine.take(6).forEach { sb.appendLine("  layer: $it") }
        if (mine.isEmpty()) sb.appendLine("  contoh layer lain: " + all.take(4).joinToString(" | "))
        for (layer in candidateLayers(pkg).take(3)) {
            val raw = Shell.exec("dumpsys SurfaceFlinger --latency '${layer.replace("'", "")}'")
            sb.appendLine("--latency $layer")
            sb.appendLine("  baris=${raw?.lines()?.size} valid=${latencyTimes(layer).size} fps=${fpsOfLayer(layer)}")
            raw?.lines()?.take(4)?.forEach { sb.appendLine("  | $it") }
        }
        val g = gfxinfoTimes(pkg)
        sb.appendLine("gfxinfo: frame=${g.size} fps=${gfxinfoFps(pkg)}")
        sb.appendLine("GPU: ${readGpu()}")
        return sb.toString()
    }

    companion object { private const val MB = 1024L * 1024L }
}
